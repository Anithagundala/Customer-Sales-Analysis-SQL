-- Customer & Sales Analysis using SQL

SELECT * FROM sales_data;

SELECT SUM(Quantity * Price) AS Total_Sales
FROM sales_data;

SELECT Product, SUM(Quantity * Price) AS Revenue
FROM sales_data
GROUP BY Product
ORDER BY Revenue DESC;

SELECT Category, SUM(Quantity * Price) AS Category_Sales
FROM sales_data
GROUP BY Category
ORDER BY Category_Sales DESC;

SELECT Region, SUM(Quantity * Price) AS Regional_Sales
FROM sales_data
GROUP BY Region
ORDER BY Regional_Sales DESC;

SELECT Customer, SUM(Quantity * Price) AS Customer_Sales
FROM sales_data
GROUP BY Customer
ORDER BY Customer_Sales DESC;

SELECT Product, Quantity
FROM sales_data
WHERE Quantity > 2;

SELECT AVG(Quantity * Price) AS Average_Order_Value
FROM sales_data;

SELECT SUM(Quantity) AS Total_Quantity
FROM sales_data;

SELECT *
FROM sales_data
ORDER BY (Quantity * Price) DESC
LIMIT 1;
